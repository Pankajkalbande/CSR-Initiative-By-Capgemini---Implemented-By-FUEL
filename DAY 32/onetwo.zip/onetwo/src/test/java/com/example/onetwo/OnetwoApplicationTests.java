package com.example.onetwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
