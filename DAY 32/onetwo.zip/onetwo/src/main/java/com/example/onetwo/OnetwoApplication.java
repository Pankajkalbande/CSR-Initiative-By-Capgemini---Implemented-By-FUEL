package com.example.onetwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetwoApplication.class, args);
	}

}
