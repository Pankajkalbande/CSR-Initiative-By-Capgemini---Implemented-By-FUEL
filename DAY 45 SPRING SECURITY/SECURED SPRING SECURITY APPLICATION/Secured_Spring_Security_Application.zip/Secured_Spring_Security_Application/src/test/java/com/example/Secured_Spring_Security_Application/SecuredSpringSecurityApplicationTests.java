package com.example.Secured_Spring_Security_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuredSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
