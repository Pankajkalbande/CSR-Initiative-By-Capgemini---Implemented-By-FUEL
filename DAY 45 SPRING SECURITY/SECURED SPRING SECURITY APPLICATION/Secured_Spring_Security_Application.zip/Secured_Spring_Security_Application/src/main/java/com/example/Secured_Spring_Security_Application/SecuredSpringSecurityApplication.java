package com.example.Secured_Spring_Security_Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuredSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuredSpringSecurityApplication.class, args);
	}

}
