package com.example.Default_Spring_Security_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefaultSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
