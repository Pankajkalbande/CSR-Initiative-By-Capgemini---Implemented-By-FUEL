package com.example.demoOnSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOnSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
