package com.example.webAppDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
