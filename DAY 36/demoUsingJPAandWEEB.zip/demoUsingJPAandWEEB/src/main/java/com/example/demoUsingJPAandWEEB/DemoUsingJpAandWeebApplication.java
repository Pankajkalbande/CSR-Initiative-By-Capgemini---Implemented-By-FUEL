package com.example.demoUsingJPAandWEEB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoUsingJpAandWeebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoUsingJpAandWeebApplication.class, args);
	}

}
