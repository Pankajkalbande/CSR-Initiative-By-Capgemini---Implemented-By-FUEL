package com.example.demoUsingJPAandWEEB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoUsingJpAandWeebApplicationTests {

	@Test
	void contextLoads() {
	}

}
