package com.example.jpaWithWebConnectDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaWithWebConnectDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
