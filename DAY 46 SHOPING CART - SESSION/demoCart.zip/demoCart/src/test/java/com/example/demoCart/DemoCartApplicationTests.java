package com.example.demoCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
