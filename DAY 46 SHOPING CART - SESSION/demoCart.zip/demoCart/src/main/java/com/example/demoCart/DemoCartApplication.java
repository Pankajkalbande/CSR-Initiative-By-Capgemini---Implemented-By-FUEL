package com.example.demoCart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCartApplication.class, args);
	}

}
